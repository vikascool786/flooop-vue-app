export default class User {
    constructor(username, firstName, lastName, email, password) {
      this.email = email;
      this.password = password;
      this.username = username;
      this.firstName = firstName;
      this.lastName = lastName;
    }
  }
  